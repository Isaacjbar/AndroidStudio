package utez.edu.mx.recyclerview4e.model

data class Contacto(
    val nombre: String,
    val mensaje: String,
    val imagen: Int,
    val hora: String,
    val numero: Int
)