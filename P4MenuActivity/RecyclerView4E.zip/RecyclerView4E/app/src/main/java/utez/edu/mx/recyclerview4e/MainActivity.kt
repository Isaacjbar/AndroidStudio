package utez.edu.mx.recyclerview4e

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import utez.edu.mx.recyclerview4e.adapter.ContactoAdapter
import utez.edu.mx.recyclerview4e.databinding.ActivityMainBinding
import utez.edu.mx.recyclerview4e.model.Contacto

class MainActivity : AppCompatActivity() {
    private  lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val lista = listOf(
            Contacto("Alan", "Ubuntu xd", R.drawable.otmar, "3:00 AM", 2)
        )

        val adaptador = ContactoAdapter(lista)
        binding.rvContactos.adapter = adaptador
        binding.rvContactos.layoutManager =
            LinearLayoutManager(this@MainActivity,
                LinearLayoutManager.VERTICAL, false)

    }
}