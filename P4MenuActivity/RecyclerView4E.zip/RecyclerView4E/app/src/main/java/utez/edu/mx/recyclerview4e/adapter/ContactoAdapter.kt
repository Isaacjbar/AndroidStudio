package utez.edu.mx.recyclerview4e.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import utez.edu.mx.recyclerview4e.databinding.ActivityMainBinding
import utez.edu.mx.recyclerview4e.databinding.LayoutContactoBinding
import utez.edu.mx.recyclerview4e.model.Contacto

class ContactoAdapter (var  lista: List<Contacto>):
    RecyclerView.Adapter<ContactoAdapter.ViewHolder>(){
    class ViewHolder(val binding: LayoutContactoBinding):
        RecyclerView.ViewHolder(binding.root){

    }
    //Crear la vista, infla el xml del layout_contacto
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return  ViewHolder(
            LayoutContactoBinding.inflate(LayoutInflater.from(parent.context)
            , parent, false))
    }
    //Llena la vista con los datos de la lista
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val contacto = lista[position]
        with(holder.binding){
            txtNombre.text = contacto.nombre
            txtMensaje.text = contacto.mensaje
            txtHora.text = contacto.hora
            txtNumero.text  = contacto.numero.toString()
            imgPerfil.setImageResource(contacto.imagen)

        }

    }
    //Devuelve la cantidad de elementos de la lista
    override fun getItemCount(): Int {

        return lista.size
    }
}